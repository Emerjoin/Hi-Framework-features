```javascript
Hi.$config.angular.modules = ["customs"];


Hi.$config.angular.run = function($rootScope){

    $rootScope.name = "Father";

};
```

 incluir teu modulo depois do Hi file
 Nao incluir run.js, eh automatico
 Module example:
 var customs = angular.module('customs',[]);


customs.service('Service1',function(){

    this.getMessage = function(){

        return "Hello World";

    };


});