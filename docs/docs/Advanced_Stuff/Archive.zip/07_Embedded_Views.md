Hello

This concept is about embeding a view in another view.
It's like an [iframe](http://www.w3schools.com/TAgs/tag_iframe.asp)


## How do you do it?

Go to your view and add a element name **embedded** as in the example:

```html
<embedded name="view1" url="controller/action" silent="true"></embedded>
```

NOTE: never close your element with **/>**
```html
<embedded name="view1" url="controller/action" silent="true"/>
```
Again, DON'T DO THAT!

#### What do this attributes that mean?

* **name** is required. It is the identifier of the view. put whatever name you like.
* **url** is required. It is .. I won't tell you that. Figure it out. I will only tell you that you can pass params as well..
* **silent** is optional. It tells Hi-Framework either to change the URL of your app or not.

## The Javascript Side

Hi will create a variable in your main view's $scope. With the name your gave to your embedded element.

```javascript
	$scope.view1
``` 

### What can you do with that??

**You can use all methods/variables of the other view's scope**

In your main view's scope, try:
```html
{{view1.varX}}
```



# $onEmbed


Porque se a unica forma de adicionar embedded views eh no codigo, "siletnt=true" ia significar que sempre que se carega a view mae, a embedded muda a url da mae. O que tambem nao faz muito sentido
 Outra coisa..
 Como se faria para se por um loader antes da embedded view ser carregada??



Thank you!


Passing Params

Passing  Params em tempo de execucao