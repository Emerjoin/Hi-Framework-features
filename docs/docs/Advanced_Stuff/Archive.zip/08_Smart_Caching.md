Smart Caching


    <web-tunning>

        <webroot>
            <folders-fixed-caching>
                <enabled age-unit="HOURS" age="1" folder-name="webroot/folder/asset/js/"/>
                <enabled age-unit="DAYS" age="1" folder-name="webroot/folder/asset/css"/>
            </folders-fixed-caching>

            <assets-smart-caching>
                <enabled>lib/ladda/spin.min.js</enabled>
                <enabled>lib/ladda/ladda.min.js</enabled>
            </assets-smart-caching>
        </webroot>

    </web-tunning>